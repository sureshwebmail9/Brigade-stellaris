/*
  # Create Leads Management System

  1. New Tables
    - `leads`
      - `id` (uuid, primary key)
      - `name` (text, required) - Lead's full name
      - `email` (text, required) - Lead's email address
      - `phone` (text, required) - Lead's phone number
      - `lead_type` (text) - Type of lead (site_visit, brochure, pricing, etc.)
      - `bhk_interest` (text) - Interested BHK configuration
      - `message` (text) - Additional message from lead
      - `utm_source` (text) - Marketing source tracking
      - `utm_medium` (text) - Marketing medium tracking
      - `utm_campaign` (text) - Campaign tracking
      - `created_at` (timestamptz) - Timestamp of lead creation
      - `status` (text) - Lead status (new, contacted, qualified, converted)
      
  2. Security
    - Enable RLS on `leads` table
    - Add policy for inserting leads (public access for form submissions)
    - Add policy for authenticated users to read all leads (for admin panel)
    
  3. Indexes
    - Index on email for duplicate checking
    - Index on created_at for sorting
    - Index on status for filtering
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  lead_type text DEFAULT 'general',
  bhk_interest text,
  message text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

-- Policy to allow anyone to insert leads (for public form submissions)
CREATE POLICY "Anyone can submit leads"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policy for authenticated users to read all leads (admin access)
CREATE POLICY "Authenticated users can read all leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy for authenticated users to update lead status
CREATE POLICY "Authenticated users can update leads"
  ON leads
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);