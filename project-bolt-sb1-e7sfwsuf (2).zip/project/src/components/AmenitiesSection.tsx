import { Waves, Dumbbell, Home, Trees, Baby, Gamepad2, Users, Footprints, Shield, Heart, Tv, Sparkles, Utensils, Sun, Trophy } from 'lucide-react';

export default function AmenitiesSection() {
  const amenities = [
    {
      icon: Waves,
      title: 'Swimming Pool',
      description: 'Resort-style swimming pool with relaxation deck'
    },
    {
      icon: Dumbbell,
      title: 'Fitness Studio',
      description: 'Fully equipped modern gymnasium'
    },
    {
      icon: Heart,
      title: 'Yoga & Dance Room',
      description: 'Dedicated space for wellness and movement'
    },
    {
      icon: Sparkles,
      title: 'Spa',
      description: 'Premium spa facilities for relaxation'
    },
    {
      icon: Trophy,
      title: 'Badminton & Squash Courts',
      description: 'Professional indoor sports facilities'
    },
    {
      icon: Tv,
      title: 'Multimedia Lounge',
      description: 'Entertainment space with modern amenities'
    },
    {
      icon: Gamepad2,
      title: 'Pickle Ball Court',
      description: 'Dedicated court for trending sports'
    },
    {
      icon: Utensils,
      title: 'BBQ & Dining Area',
      description: 'Outdoor cooking and gathering space'
    },
    {
      icon: Sun,
      title: 'Rooftop Seating',
      description: 'Scenic terrace with panoramic views'
    },
    {
      icon: Users,
      title: 'Business Center',
      description: 'Professional workspace with modern facilities'
    },
    {
      icon: Footprints,
      title: 'Indoor Recreation',
      description: 'Multi-purpose activity and entertainment spaces'
    },
    {
      icon: Baby,
      title: "Kids' Play Area",
      description: 'Safe and engaging play zones for children'
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Resort-Style Amenities
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Premium lifestyle facilities designed to enhance every aspect of modern living at Brigade Stellaris
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {amenities.map((amenity, idx) => (
            <div
              key={idx}
              className="group bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 hover:border-amber-500"
            >
              <div className="bg-gradient-to-br from-amber-500 to-amber-600 w-16 h-16 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <amenity.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-amber-600 transition-colors">
                {amenity.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {amenity.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-8 lg:p-12 text-white shadow-2xl">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-3xl lg:text-4xl font-bold mb-4">
                Experience Luxury Redefined
              </h3>
              <p className="text-lg text-amber-50 mb-6">
                Every amenity at Brigade Stellaris is meticulously designed to enhance your lifestyle and provide unparalleled comfort for you and your family.
              </p>
              <ul className="space-y-3">
                {[
                  'Elevated clubhouse with premium amenities',
                  'Biophilic design integrated throughout',
                  'Family-friendly wellness facilities',
                  'Professional-grade sports and recreation'
                ].map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-white rounded-full" />
                    <span className="text-amber-50">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="text-center lg:text-right">
              <button
                onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-amber-600 hover:bg-amber-50 px-10 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-xl"
              >
                Schedule a Tour
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
