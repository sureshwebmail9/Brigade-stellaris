import { Building2, Users, MapPin, Home } from 'lucide-react';

export default function CredibilitySection() {
  const stats = [
    { icon: Building2, value: '39', label: 'Years of Excellence' },
    { icon: Home, value: '300+', label: 'Buildings' },
    { icon: Users, value: '50,000+', label: 'Happy Customers' },
    { icon: MapPin, value: '9', label: 'Cities' }
  ];

  return (
    <section className="py-16 lg:py-24 bg-gray-900 text-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">
            Backed by <span className="text-amber-400">Brigade Group</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Forging landmark projects and transformative spaces that inspire. Fueled by a vision of a brighter future, since 1986, we have been making room for limitless possibilities with each architectural masterpiece.
          </p>
          <p className="text-lg text-gray-300 max-w-4xl mx-auto">
            As one of India's most revered and prestigious property developers, Brigade has been meticulously shaping the urban real estate landscape across Indian cities. We have carved a distinct niche for ourselves by crafting lifestyle-defining developments in the Residential, Commercial, Retail, Hospitality, and Education sectors. Our visionary real estate concepts have etched an indelible mark on the skylines of Bengaluru, Chennai, Hyderabad, Mysuru, Kochi, Thiruvananthapuram, GIFT City Gujarat, Mangalore, and Chikmagalur.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, idx) => (
            <div
              key={idx}
              className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 backdrop-blur-sm border border-amber-500/20 rounded-xl p-8 text-center hover:border-amber-500/40 transition-all"
            >
              <div className="bg-amber-500/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-8 h-8 text-amber-400" />
              </div>
              <div className="text-4xl lg:text-5xl font-bold text-amber-400 mb-2">
                {stat.value}
              </div>
              <div className="text-gray-300 font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 lg:p-12">
          <div className="text-center">
            <p className="text-lg text-gray-300 max-w-3xl mx-auto mb-6">
              <span className="text-amber-400 font-semibold">100+ Mn Sq. Ft Delivered</span> across multiple segments, creating spaces that inspire and endure.
            </p>
            <p className="text-gray-300">
              Brigade Stellaris is designed by award-winning <span className="text-amber-400 font-semibold">SOG Design, Singapore</span>, bringing world-class biophilic architecture to Chennai.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
