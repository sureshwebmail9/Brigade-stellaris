import { useState } from 'react';
import { Maximize2 } from 'lucide-react';

interface FloorPlansSectionProps {
  onOpenPopup: (context: string) => void;
}

export default function FloorPlansSection({ onOpenPopup }: FloorPlansSectionProps) {
  const [activeTab, setActiveTab] = useState('3bhk');

  const floorPlans = {
    '3bhk': {
      title: '3 BHK',
      area: '2,033 - 2,642 sq.ft',
      image: '/WhatsApp_Image_2026-03-01_at_11.39.54_AM_(1).jpeg',
      features: ['Duplex layout with spacious living', 'Master bedroom with walk-in closet', 'Two additional bedrooms', 'Premium modular kitchen', 'Multiple balconies with views', 'Biophilic design elements']
    },
    '4bhk': {
      title: '4 BHK',
      area: '3,200 - 3,484 sq.ft',
      image: '/WhatsApp_Image_2026-03-01_at_11.39.54_AM.jpeg',
      features: ['Expansive duplex living', 'Master suite with luxury ensuite', 'Three additional bedrooms', 'Designer kitchen with breakfast area', 'Separate family lounge', 'Private terraces', 'Natural light throughout']
    },
    '5bhk': {
      title: '5 BHK Signature Duplex',
      area: '4,500+ sq.ft',
      image: '/WhatsApp_Image_2026-03-01_at_11.39.54_AM.jpeg',
      features: ['Ultra-luxurious duplex layout', 'Grand master suite with spa-like bathroom', 'Four additional bedrooms', 'Gourmet kitchen with island', 'Private lounge and entertainment area', 'Exclusive terraces with panoramic views', 'Signature SOG design elements']
    }
  };

  const currentPlan = floorPlans[activeTab as keyof typeof floorPlans];

  return (
    <section id="floor-plans" className="py-16 lg:py-24 bg-gradient-to-br from-gray-50 via-white to-gray-50">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Floor Plans
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Crafted by SOG Design, Singapore - one inch lower design philosophy for enhanced living
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="inline-flex bg-white rounded-xl shadow-lg p-2 gap-2">
            {Object.entries(floorPlans).map(([key, plan]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`px-8 py-3 rounded-lg font-semibold transition-all ${
                  activeTab === key
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {plan.title}
              </button>
            ))}
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="relative group">
              <img
                src={currentPlan.image}
                alt={`${currentPlan.title} floor plan`}
                className="w-full h-full object-cover min-h-[400px]"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button className="bg-white text-gray-800 px-6 py-3 rounded-lg font-semibold flex items-center gap-2 transform scale-90 group-hover:scale-100 transition-transform">
                  <Maximize2 className="w-5 h-5" />
                  View Full Plan
                </button>
              </div>
            </div>

            <div className="p-8 lg:p-12">
              <h3 className="text-3xl font-bold text-gray-800 mb-3">
                {currentPlan.title}
              </h3>
              <div className="text-amber-600 font-semibold text-xl mb-6">
                {currentPlan.area}
              </div>

              <div className="space-y-4 mb-8">
                <h4 className="font-semibold text-gray-800 text-lg">Key Features:</h4>
                <ul className="space-y-3">
                  {currentPlan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-amber-500 rounded-full" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => onOpenPopup('Request Floor Plan Details')}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-xl"
              >
                Request Floor Plan Details
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
