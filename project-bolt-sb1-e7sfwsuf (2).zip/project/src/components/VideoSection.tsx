export default function VideoSection() {
  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4">
            Experience Brigade Stellaris
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Take a virtual tour of your future home
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ paddingBottom: '56.25%' }}>
            <iframe
              className="absolute top-0 left-0 w-full h-full"
              src="https://www.youtube.com/embed/OnDmVzp5MdA?autoplay=1&mute=1&loop=1&playlist=OnDmVzp5MdA&controls=1&modestbranding=1&rel=0"
              title="Brigade Stellaris Virtual Tour"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    </section>
  );
}
