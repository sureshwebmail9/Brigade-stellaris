import { useState } from 'react';
import { IndianRupee, Calculator, Shield, Maximize2 } from 'lucide-react';

interface PricingSectionProps {
  onOpenPopup: (context: string) => void;
}

export default function PricingSection({ onOpenPopup }: PricingSectionProps) {
  const [loanAmount, setLoanAmount] = useState(5000000);
  const [interestRate, setInterestRate] = useState(8.5);
  const [tenure, setTenure] = useState(20);

  const calculateEMI = () => {
    const principal = loanAmount;
    const ratePerMonth = interestRate / 12 / 100;
    const numberOfMonths = tenure * 12;

    const emi =
      (principal * ratePerMonth * Math.pow(1 + ratePerMonth, numberOfMonths)) /
      (Math.pow(1 + ratePerMonth, numberOfMonths) - 1);

    return Math.round(emi);
  };

  const pricingOptions = [
    {
      type: '3 BHK Regular',
      price: '₹4.49 Cr - ₹4.75 Cr',
      area: '2,033 - 2,116 sq.ft',
      status: 'Available'
    },
    {
      type: '3 BHK + Maid',
      price: '₹5.49 Cr - ₹5.92 Cr',
      area: '2,480 - 2,642 sq.ft',
      status: 'Available'
    },
    {
      type: '4 BHK',
      price: '₹7.28 Cr - ₹7.98 Cr',
      area: '3,200 - 3,484 sq.ft',
      status: 'Selling Fast'
    },
    {
      type: '4 BHK Duplex',
      price: '₹11.62 Cr - ₹12.32 Cr',
      area: '4,657 - 4,903 sq.ft',
      status: 'Limited Units'
    },
    {
      type: '5 BHK Duplex',
      price: '₹15.33 Cr - ₹16.10 Cr',
      area: '5,989 - 6,337 sq.ft',
      status: 'Limited Units'
    }
  ];

  const emi = calculateEMI();
  const totalPayment = emi * tenure * 12;
  const totalInterest = totalPayment - loanAmount;

  return (
    <section id="pricing" className="py-16 lg:py-24 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Pricing & Investment Details
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            284 exclusive signature duplex residences across 4 towers in 5 acres of biophilic design
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-16">
          {pricingOptions.map((option, idx) => (
            <div
              key={idx}
              className="bg-gradient-to-br from-gray-50 to-white rounded-xl shadow-lg hover:shadow-2xl transition-all p-6 border-2 border-transparent hover:border-amber-500"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-800">{option.type}</h3>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  option.status === 'Available' ? 'bg-green-100 text-green-800' :
                  option.status === 'Selling Fast' ? 'bg-amber-100 text-amber-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {option.status}
                </span>
              </div>
              <div className="mb-6">
                <div className="text-3xl font-bold text-amber-600 mb-2">
                  {option.price}
                </div>
                <div className="text-gray-600 flex items-center gap-2">
                  <Maximize2 className="w-4 h-4" />
                  {option.area}
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {[
                  'Duplex configuration',
                  'SOG Design architecture',
                  'Biophilic design elements',
                  'Elevated clubhouse access'
                ].map((feature, featureIdx) => (
                  <li key={featureIdx} className="flex items-center gap-3 text-gray-600">
                    <div className="w-2 h-2 bg-amber-500 rounded-full" />
                    {feature}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => onOpenPopup('Get Detailed Pricing')}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all"
              >
                Get Detailed Pricing
              </button>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="bg-gradient-to-br from-amber-50 to-white rounded-2xl shadow-xl p-8 lg:p-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="bg-amber-500 p-3 rounded-lg">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800">EMI Calculator</h3>
            </div>

            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-gray-700 font-medium">Loan Amount</label>
                  <span className="text-amber-600 font-semibold">
                    ₹{loanAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <input
                  type="range"
                  min="1000000"
                  max="20000000"
                  step="100000"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>₹10L</span>
                  <span>₹2Cr</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-gray-700 font-medium">Interest Rate (%)</label>
                  <span className="text-amber-600 font-semibold">{interestRate}%</span>
                </div>
                <input
                  type="range"
                  min="6"
                  max="12"
                  step="0.1"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>6%</span>
                  <span>12%</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-gray-700 font-medium">Loan Tenure (Years)</label>
                  <span className="text-amber-600 font-semibold">{tenure} years</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="30"
                  step="1"
                  value={tenure}
                  onChange={(e) => setTenure(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>5 years</span>
                  <span>30 years</span>
                </div>
              </div>
            </div>

            <div className="mt-8 bg-gradient-to-r from-amber-500 to-amber-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg">Monthly EMI</span>
                <div className="flex items-center gap-2">
                  <IndianRupee className="w-6 h-6" />
                  <span className="text-3xl font-bold">{emi.toLocaleString('en-IN')}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm border-t border-white/20 pt-4">
                <div>
                  <div className="text-amber-100">Principal Amount</div>
                  <div className="font-semibold">₹{(loanAmount / 100000).toFixed(1)}L</div>
                </div>
                <div>
                  <div className="text-amber-100">Total Interest</div>
                  <div className="font-semibold">₹{(totalInterest / 100000).toFixed(1)}L</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8 lg:p-10 border border-gray-100">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-green-500 p-3 rounded-lg">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800">Price Assurance</h3>
            </div>

            <div className="space-y-6 mb-8">
              {[
                'Transparent pricing with no hidden costs',
                '5 acres of biophilic design excellence',
                'Award-winning SOG Design architecture',
                'Only 284 signature residences',
                'RERA approved project',
                'Flexible payment plans available'
              ].map((item, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                  </div>
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => onOpenPopup('Request Complete Cost Sheet')}
              className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-xl"
            >
              Request Complete Cost Sheet
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
