import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, MapPin, Building2, Award } from 'lucide-react';
import { submitLead, Lead } from '../lib/supabase';

const heroImages = [
  '/WhatsApp_Image_2026-03-03_at_12.08.00_PM.jpeg',
  '/WhatsApp_Image_2026-03-02_at_9.37.46_PM_(1).jpeg',
  '/WhatsApp_Image_2026-03-02_at_9.37.46_PM_(2).jpeg',
  '/WhatsApp_Image_2026-03-02_at_9.37.46_PM.jpeg'
];

interface HeroSectionProps {
  onOpenPopup: (context: string) => void;
}

export default function HeroSection({ onOpenPopup }: HeroSectionProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const handleSubmit = async (e: React.FormEvent, leadType: string) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.email) return;

    setIsSubmitting(true);
    try {
      const lead: Lead = {
        ...formData,
        lead_type: leadType
      };
      await submitLead(lead);
      setShowSuccess(true);
      setFormData({ name: '', phone: '', email: '' });
      setTimeout(() => setShowSuccess(false), 5000);
    } catch (error) {
      console.error('Error submitting lead:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroImages.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + heroImages.length) % heroImages.length);

  return (
    <section className="relative h-screen min-h-[550px] sm:min-h-[600px] overflow-hidden">
      <div className="absolute inset-0">
        {heroImages.map((img, idx) => (
          <div
            key={idx}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              idx === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={img}
              alt={`Brigade Stellaris luxury apartments ${idx + 1}`}
              className="w-full h-full object-cover"
              loading={idx === 0 ? 'eager' : 'lazy'}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
          </div>
        ))}
      </div>

      <button
        onClick={prevSlide}
        className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-10 bg-white/10 hover:bg-white/20 backdrop-blur-sm p-2 sm:p-3 rounded-full transition-all"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-10 bg-white/10 hover:bg-white/20 backdrop-blur-sm p-2 sm:p-3 rounded-full transition-all"
        aria-label="Next slide"
      >
        <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
      </button>

      <div className="relative z-10 h-full flex items-center pt-16 sm:pt-20 pb-6">
        <div className="container mx-auto px-3 sm:px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 items-center">
            <div className="text-white space-y-3 sm:space-y-4 lg:space-y-6">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight">
                Experience Elevated Living
              </h1>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3 lg:gap-4 pt-2 sm:pt-4 lg:pt-6">
                {[
                  { icon: MapPin, text: '5 Acres in Velachery' },
                  { icon: Building2, text: '284 Signature Homes' },
                  { icon: Award, text: 'SOG Design' }
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 sm:gap-3 bg-white/10 backdrop-blur-md px-3 sm:px-4 py-2 sm:py-3 rounded-lg">
                    <item.icon className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 flex-shrink-0" />
                    <span className="text-sm sm:text-base font-medium">{item.text}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-2 sm:pt-4">
                <button
                  onClick={() => onOpenPopup('Book Site Visit')}
                  className="bg-amber-500 hover:bg-amber-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold text-base sm:text-lg transition-all transform hover:scale-105 shadow-xl w-full sm:w-auto"
                >
                  Book Site Visit
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-2xl p-4 sm:p-6 lg:p-8 max-w-md mx-auto w-full">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6 text-center">
                Get Exclusive Pricing Details
              </h3>

              {showSuccess ? (
                <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-6 rounded-lg text-center">
                  <p className="font-semibold">Thank you for your interest!</p>
                  <p className="text-sm mt-2">Our team will contact you shortly.</p>
                </div>
              ) : (
                <form onSubmit={(e) => handleSubmit(e, 'hero_form')} className="space-y-3 sm:space-y-4">
                  <input
                    type="text"
                    placeholder="Full Name *"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 sm:px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none text-base"
                    required
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number *"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 sm:px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none text-base"
                    required
                  />
                  <input
                    type="email"
                    placeholder="Email Address *"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 sm:px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none text-base"
                    required
                  />
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3 sm:py-4 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed text-base"
                  >
                    {isSubmitting ? 'Submitting...' : 'Book Now'}
                  </button>
                  <p className="text-xs text-gray-500 text-center">
                    By submitting, you agree to our privacy policy
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 sm:bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {heroImages.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2 sm:h-3 rounded-full transition-all ${
              idx === currentSlide ? 'bg-amber-400 w-6 sm:w-8' : 'bg-white/50 w-2 sm:w-3'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
