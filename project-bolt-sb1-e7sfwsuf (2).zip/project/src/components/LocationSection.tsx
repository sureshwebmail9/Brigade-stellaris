import { MapPin, Train, Plane, Building2, GraduationCap, Heart, ShoppingBag, Clock } from 'lucide-react';

export default function LocationSection() {
  const highlights = [
    { icon: MapPin, text: 'Prime location on Velachery Main Road, South Chennai' },
    { icon: ShoppingBag, text: 'Just opposite Phoenix Marketcity' },
    { icon: Train, text: '2 mins to Velachery MRTS Station' },
    { icon: Building2, text: 'Excellent connectivity to Old Mahabalipuram Road (OMR IT Corridor)' },
    { icon: Building2, text: 'Easy access to Guindy & Central Business District' },
    { icon: Plane, text: '20–25 mins drive to Chennai International Airport' },
    { icon: Building2, text: 'Close to major IT parks in Taramani & Perungudi' },
    { icon: GraduationCap, text: 'Surrounded by reputed schools & colleges' },
    { icon: Heart, text: 'Leading hospitals nearby including Apollo Hospitals' },
    { icon: Clock, text: 'Quick access to GST Road & Mount Road corridors' },
    { icon: MapPin, text: 'Well-developed social infrastructure & high rental demand zone' }
  ];

  return (
    <section id="location" className="py-16 lg:py-24 bg-gradient-to-br from-white via-gray-50 to-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Location Highlights
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Brigade Stellaris, Velachery - Where convenience meets connectivity
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {highlights.map((highlight, idx) => {
              const Icon = highlight.icon;
              return (
                <div key={idx} className="flex items-start gap-4 bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                  <div className="bg-amber-100 p-3 rounded-lg flex-shrink-0">
                    <Icon className="w-6 h-6 text-amber-600" />
                  </div>
                  <p className="text-gray-700 leading-relaxed pt-1">{highlight.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
