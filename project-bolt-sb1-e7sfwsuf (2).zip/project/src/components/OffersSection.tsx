import { Clock, Gift, IndianRupee, Award } from 'lucide-react';

interface OffersSectionProps {
  onOpenPopup: (context: string) => void;
}

export default function OffersSection({ onOpenPopup }: OffersSectionProps) {
  const launchBenefits = [
    {
      type: '3 BHK Regular',
      area: '2,033 - 2,116 sq.ft',
      price: '₹4.49 Cr - ₹4.75 Cr',
      benefit: '₹10 Lakhs'
    },
    {
      type: '3 BHK + Maid',
      area: '2,480 - 2,642 sq.ft',
      price: '₹5.49 Cr - ₹5.92 Cr',
      benefit: '₹12 Lakhs'
    },
    {
      type: '4 BHK',
      area: '3,200 - 3,484 sq.ft',
      price: '₹7.28 Cr - ₹7.98 Cr',
      benefit: '₹15 Lakhs'
    },
    {
      type: '4 BHK Duplex',
      area: '4,657 - 4,903 sq.ft',
      price: '₹11.62 Cr - ₹12.32 Cr',
      benefit: '₹20 Lakhs'
    },
    {
      type: '5 BHK Duplex',
      area: '5,989 - 6,337 sq.ft',
      price: '₹15.33 Cr - ₹16.10 Cr',
      benefit: '₹27 Lakhs'
    }
  ];

  const highlights = [
    {
      icon: Gift,
      title: 'Limited Period Offer',
      description: 'For first 45 residences only',
      highlight: 'Exclusive'
    },
    {
      icon: Award,
      title: 'Premium Benefits',
      description: 'Up to ₹27 Lakhs launch benefit',
      highlight: 'Best Value'
    },
    {
      icon: Clock,
      title: 'Act Now',
      description: 'Limited units available',
      highlight: 'Urgent'
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-amber-50 via-white to-amber-50">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Inaugural Launch Benefit
          </h2>
          <p className="text-xl text-gray-600 mb-2">
            Exclusive benefits for the first 45 residences
          </p>
          <p className="text-sm text-gray-500">
            * All prices are inclusive | Prices exclude Registration & Stamp duty charges
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-4 sm:p-6 lg:p-12 max-w-6xl mx-auto mb-12 relative min-h-[400px] sm:min-h-[450px]">
          <div className="relative h-full">
            <div className="overflow-x-auto blur-sm select-none pointer-events-none">
              <table className="w-full min-w-[600px]">
                <thead>
                  <tr className="bg-gray-900 text-white">
                    <th className="px-2 sm:px-4 py-3 sm:py-4 text-left font-semibold text-xs sm:text-sm">Typology</th>
                    <th className="px-2 sm:px-4 py-3 sm:py-4 text-left font-semibold text-xs sm:text-sm">SBA (Sq.Ft)</th>
                    <th className="px-2 sm:px-4 py-3 sm:py-4 text-left font-semibold text-xs sm:text-sm">Price (CR)</th>
                    <th className="px-2 sm:px-4 py-3 sm:py-4 text-left font-semibold text-xs sm:text-sm">Benefit</th>
                  </tr>
                </thead>
                <tbody>
                  {launchBenefits.map((item, idx) => (
                    <tr key={idx} className="border-b border-gray-200">
                      <td className="px-2 sm:px-4 py-3 sm:py-4 font-semibold text-gray-800 text-xs sm:text-sm">{item.type}</td>
                      <td className="px-2 sm:px-4 py-3 sm:py-4 text-gray-600 text-xs sm:text-sm">{item.area}</td>
                      <td className="px-2 sm:px-4 py-3 sm:py-4 text-gray-600 text-xs sm:text-sm">{item.price}</td>
                      <td className="px-2 sm:px-4 py-3 sm:py-4">
                        <div className="flex items-center gap-1 sm:gap-2 text-green-700 font-bold text-xs sm:text-sm">
                          <IndianRupee className="w-3 h-3 sm:w-4 sm:h-4" />
                          {item.benefit}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="absolute inset-0 flex items-center justify-center bg-white/90 backdrop-blur-sm">
              <div className="text-center p-4 sm:p-6 lg:p-8 max-w-md mx-4">
                <div className="bg-amber-100 w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                  <Gift className="w-8 h-8 sm:w-10 sm:h-10 text-amber-600" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-3 sm:mb-4">
                  Unlock Exclusive Launch Benefits
                </h3>
                <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6">
                  Get complete pricing details and launch benefits worth up to ₹27 Lakhs
                </p>
                <button
                  onClick={() => onOpenPopup('Contact to Know Benefits')}
                  className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold text-base sm:text-lg transition-all transform hover:scale-105 shadow-xl inline-flex items-center gap-2"
                >
                  <Gift className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="whitespace-nowrap">Contact to Know Benefits</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {highlights.map((highlight, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all transform hover:-translate-y-2 border-t-4 border-amber-500"
            >
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                <highlight.icon className="w-8 h-8 text-amber-600" />
              </div>
              <div className="text-center">
                <div className="text-amber-600 font-bold text-sm mb-2">
                  {highlight.highlight}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">
                  {highlight.title}
                </h3>
                <p className="text-gray-600">
                  {highlight.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
