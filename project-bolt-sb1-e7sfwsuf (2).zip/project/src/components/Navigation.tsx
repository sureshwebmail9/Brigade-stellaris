import { useState, useEffect } from 'react';
import { Building2, Phone, Mail } from 'lucide-react';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white shadow-lg py-2 sm:py-3 lg:py-4'
          : 'bg-transparent py-3 sm:py-4 lg:py-6'
      }`}
    >
      <div className="container mx-auto px-3 sm:px-4 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className={`${isScrolled ? 'bg-amber-500' : 'bg-white'} p-1.5 sm:p-2 rounded-lg`}>
              <Building2 className={`w-5 h-5 sm:w-6 sm:h-6 ${isScrolled ? 'text-white' : 'text-amber-600'}`} />
            </div>
            <div>
              <div className={`font-bold text-sm sm:text-base lg:text-xl ${isScrolled ? 'text-gray-800' : 'text-white'}`}>
                Brigade Stellaris
              </div>
              <div className={`text-[10px] sm:text-xs ${isScrolled ? 'text-gray-600' : 'text-gray-200'}`}>
                by Brigade Group
              </div>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white hover:text-amber-400'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection('floor-plans')}
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white hover:text-amber-400'
              }`}
            >
              Floor Plans
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white hover:text-amber-400'
              }`}
            >
              Pricing
            </button>
            <button
              onClick={() => scrollToSection('contact-form')}
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white hover:text-amber-400'
              }`}
            >
              Contact
            </button>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 lg:gap-4">
            <a
              href="tel:+919876543210"
              className="hidden md:flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-4 lg:px-6 py-1.5 lg:py-2 rounded-lg font-semibold transition-all text-sm lg:text-base"
            >
              <Phone className="w-3.5 h-3.5 lg:w-4 lg:h-4" />
              <span className="hidden lg:inline">Call Now</span>
              <span className="lg:hidden">Call</span>
            </a>
            <button
              onClick={() => scrollToSection('contact-form')}
              className={`px-3 sm:px-4 lg:px-6 py-1.5 sm:py-2 rounded-lg font-semibold transition-all text-xs sm:text-sm lg:text-base ${
                isScrolled
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white'
                  : 'bg-white text-amber-600'
              }`}
            >
              Book Now
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
