import { useState } from 'react';
import { Phone, Mail, MapPin, Send } from 'lucide-react';
import { submitLead } from '../lib/supabase';

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    bhk_interest: '2bhk',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.email) return;

    setIsSubmitting(true);
    try {
      await submitLead({
        ...formData,
        lead_type: 'contact_form'
      });
      setShowSuccess(true);
      setFormData({
        name: '',
        phone: '',
        email: '',
        bhk_interest: '2bhk',
        message: ''
      });
      setTimeout(() => setShowSuccess(false), 5000);
    } catch (error) {
      console.error('Error submitting lead:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact-form" className="py-16 lg:py-24 bg-gradient-to-br from-gray-50 via-white to-amber-50">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Get in Touch
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our team is ready to help you find your perfect home at Brigade Stellaris
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 max-w-6xl mx-auto">
          <div className="space-y-6 lg:space-y-8">
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6">
                Why Choose Brigade Stellaris?
              </h3>
              <ul className="space-y-3 sm:space-y-4">
                {[
                  '5 acres of biophilic design excellence',
                  'Designed by award-winning SOG Design, Singapore',
                  '284 signature 3BHK, 4BHK & 5BHK Duplex residences',
                  'Elevated clubhouse with curated amenities',
                  'RERA registered - TNRERA/29/BLG/0052/2026',
                  'Prime Velachery location with seamless access'
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 sm:gap-3">
                    <div className="w-5 h-5 sm:w-6 sm:h-6 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-amber-500 rounded-full" />
                    </div>
                    <span className="text-sm sm:text-base text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8 space-y-4 sm:space-y-6">
              <h4 className="text-lg sm:text-xl font-bold text-gray-800">Contact Information</h4>

              <div className="flex items-start gap-3 sm:gap-4">
                <div className="bg-amber-100 p-2.5 sm:p-3 rounded-lg">
                  <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-800 text-sm sm:text-base">Phone</div>
                  <a href="tel:+919940447316" className="text-sm sm:text-base text-gray-600 hover:text-amber-600 transition-colors">
                    +91 99404 47316
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 sm:gap-4">
                <div className="bg-amber-100 p-2.5 sm:p-3 rounded-lg">
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-800 text-sm sm:text-base">Email</div>
                  <a href="mailto:ram.realty1987@gmail.com" className="text-sm sm:text-base text-gray-600 hover:text-amber-600 transition-colors break-all">
                    ram.realty1987@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 sm:gap-4">
                <div className="bg-amber-100 p-2.5 sm:p-3 rounded-lg">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-800 text-sm sm:text-base">Address</div>
                  <p className="text-sm sm:text-base text-gray-600 mb-3">
                    Old No.66, Velachery Main Rd<br />
                    Near Phoenix Market City<br />
                    Velachery, Chennai - 600042
                  </p>
                  <a
                    href="https://maps.app.goo.gl/FexJh2NuPn4WQng68?g_st=aw"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium transition-colors text-sm sm:text-base"
                  >
                    <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    View on Google Maps
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-2xl p-6 sm:p-8 lg:p-10">
            <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-2">
              Schedule Your Site Visit
            </h3>
            <p className="text-amber-600 font-semibold mb-4 sm:mb-6 text-sm sm:text-base">
              Get exclusive launch benefits details up to ₹27 Lakhs
            </p>

            {showSuccess ? (
              <div className="bg-green-50 border border-green-200 text-green-800 px-4 sm:px-6 py-6 sm:py-8 rounded-lg text-center">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <Send className="w-7 h-7 sm:w-8 sm:h-8 text-green-600" />
                </div>
                <p className="font-semibold text-base sm:text-lg mb-2">Thank you for your interest!</p>
                <p className="text-xs sm:text-sm">Our team will contact you shortly to schedule your site visit.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                <div>
                  <label className="block text-gray-700 font-medium mb-2 text-sm sm:text-base">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                    required
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2 text-sm sm:text-base">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3 sm:px-4 py-2.5 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 font-medium mb-2 text-sm sm:text-base">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3 sm:px-4 py-2.5 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 font-medium mb-2 text-sm sm:text-base">
                    Interested In
                  </label>
                  <select
                    value={formData.bhk_interest}
                    onChange={(e) => setFormData({ ...formData, bhk_interest: e.target.value })}
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                  >
                    <option value="3bhk">3 BHK</option>
                    <option value="4bhk">4 BHK</option>
                    <option value="5bhk_duplex">5 BHK Duplex</option>
                    <option value="not_sure">Not Sure</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 font-medium mb-2 text-sm sm:text-base">
                    Message (Optional)
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={4}
                    className="w-full px-3 sm:px-4 py-2.5 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none resize-none"
                    placeholder="Any specific requirements or questions?"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold py-3 sm:py-4 text-sm sm:text-base rounded-lg transition-all transform hover:scale-105 shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4 sm:w-5 sm:h-5" />
                  {isSubmitting ? 'Submitting...' : 'Submit Inquiry'}
                </button>

                <p className="text-xs sm:text-sm text-gray-500 text-center">
                  By submitting this form, you agree to our privacy policy and consent to be contacted by our team.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
