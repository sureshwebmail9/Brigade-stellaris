import { Play } from 'lucide-react';

export default function VideoWalkthroughSection() {
  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4">
            Project Walkthrough
          </h2>
          <p className="text-xl text-gray-300">
            Experience Brigade Stellaris through our virtual tour
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-black" style={{ paddingBottom: '56.25%' }}>
            <iframe
              className="absolute top-0 left-0 w-full h-full"
              src="https://www.youtube.com/embed/OnDmVzp5MdA?autoplay=1&mute=1&loop=1&playlist=OnDmVzp5MdA&controls=1&modestbranding=1&rel=0"
              title="Brigade Stellaris Project Walkthrough"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          <div className="mt-8 text-center">
            <div className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-md px-6 py-3 rounded-full">
              <Play className="w-5 h-5 text-amber-400" />
              <p className="text-white text-sm">
                Watch the complete project walkthrough and amenities showcase
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
