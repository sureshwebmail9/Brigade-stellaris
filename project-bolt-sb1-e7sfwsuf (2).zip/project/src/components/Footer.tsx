import { Building2, MapPin, Phone, Mail, Facebook, Instagram, Linkedin, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-amber-500 p-2 rounded-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-bold text-xl">Brigade Stellaris</div>
                <div className="text-sm text-gray-400">by Brigade Group</div>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              A new benchmark in biophilic design across 5 acres in Velachery. 284 signature 3BHK, 4BHK & 5BHK Duplex residences designed by SOG Design, Singapore.
            </p>
            <div className="flex gap-4">
              {[
                { icon: Facebook, href: '#' },
                { icon: Instagram, href: '#' },
                { icon: Linkedin, href: '#' },
                { icon: Youtube, href: '#' }
              ].map((social, idx) => (
                <a
                  key={idx}
                  href={social.href}
                  className="bg-white/10 hover:bg-amber-500 p-2 rounded-lg transition-all"
                  aria-label={social.icon.name}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {[
                'About Brigade Group',
                'Floor Plans',
                'Amenities',
                'Pricing',
                'Location',
                'Gallery'
              ].map((link, idx) => (
                <li key={idx}>
                  <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-amber-400 flex-shrink-0 mt-1" />
                <span className="text-gray-400">
                  Brigade Stellaris<br />
                  Old No.66, Velachery Main Rd<br />
                  Velachery, Chennai - 600042
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <a href="tel:+919940447316" className="text-gray-400 hover:text-amber-400 transition-colors">
                  +91 99404 47316
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <a href="mailto:ram.realty1987@gmail.com" className="text-gray-400 hover:text-amber-400 transition-colors">
                  ram.realty1987@gmail.com
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Location Map</h3>
            <div className="bg-gray-800 rounded-lg overflow-hidden h-48">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.7838!2d80.2204!3d12.9748!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525d8f8b9f0001%3A0x1234!2sVelachery%20Main%20Road%2C%20Chennai!5e0!3m2!1sen!2sin!4v1709308800000!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Brigade Stellaris Location"
              />
            </div>
            <a
              href="https://maps.app.goo.gl/FexJh2NuPn4WQng68?g_st=aw"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-4 text-amber-400 hover:text-amber-300 transition-colors"
            >
              <MapPin className="w-4 h-4" />
              <span className="text-sm">View on Google Maps</span>
            </a>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
            <p>
              2026 Brigade Stellaris. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-amber-400 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-amber-400 transition-colors">Terms of Service</a>
              <a href="https://www.rera.tn.gov.in/" target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors">RERA</a>
            </div>
          </div>
          <div className="mt-6 text-xs text-gray-500 text-center md:text-left space-y-2">
            <p>
              RERA Number: TNRERA/29/BLG/0052/2026 | Available at <a href="https://www.rera.tn.gov.in/" target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors">https://www.rera.tn.gov.in/</a>
            </p>
            <p>
              All specifications and amenities are subject to change as per RERA approved plans.
            </p>
            <div className="pt-4 border-t border-gray-800">
              <p className="mb-3"><strong>Disclaimer:</strong></p>
              <p className="leading-relaxed">
                The content presented on this website is solely for informational purposes and does not constitute a service offer. Prices mentioned here are subject to change without prior notification, and the availability of the listed properties is not assured. Images showcased are illustrative and may not precisely represent the actual properties. Kindly be advised that this website operates as an authorized marketing partner (Home Quest). For necessary processing, we may share data with Real Estate Regulatory Authority (RERA) registered brokers/companies. Additionally, updates and information may be sent to the registered mobile number or email ID. All rights reserved. This website's content, design, and data are protected by copyright and other intellectual property rights. Unauthorized use or reproduction of the content may be subject to legal repercussions. For precise and current information on services, pricing, availability, or any other details, we recommend you contact us directly via the provided contact information on this website. We appreciate your visit.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
