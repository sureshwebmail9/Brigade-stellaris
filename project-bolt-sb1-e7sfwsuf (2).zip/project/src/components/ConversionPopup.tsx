import { useState, useEffect } from 'react';
import { X, Gift } from 'lucide-react';
import { submitLead } from '../lib/supabase';

interface ConversionPopupProps {
  isOpen: boolean;
  onClose: () => void;
  context?: string;
}

export default function ConversionPopup({ isOpen, onClose, context }: ConversionPopupProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
      setHasSubmitted(false);
    }
  }, [isOpen]);

  useEffect(() => {
    const hasSeenPopup = sessionStorage.getItem('popupSeen');
    if (hasSeenPopup || isOpen) return;

    const showPopup = () => {
      setIsVisible(true);
      sessionStorage.setItem('popupSeen', 'true');
    };

    const timer = setTimeout(showPopup, 10000);

    const handleScroll = () => {
      const scrollPercentage = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      if (scrollPercentage > 50 && !hasSeenPopup) {
        showPopup();
        window.removeEventListener('scroll', handleScroll);
      }
    };

    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !hasSeenPopup) {
        showPopup();
        document.removeEventListener('mouseleave', handleMouseLeave);
      }
    };

    window.addEventListener('scroll', handleScroll);
    document.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.email) return;

    setIsSubmitting(true);
    try {
      await submitLead({
        ...formData,
        lead_type: context || 'popup',
        message: context
      });
      setHasSubmitted(true);
      setTimeout(() => {
        setIsVisible(false);
        onClose();
        setFormData({ name: '', phone: '', email: '' });
      }, 3000);
    } catch (error) {
      console.error('Error submitting lead:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setIsVisible(false);
    onClose();
    setFormData({ name: '', phone: '', email: '' });
    setHasSubmitted(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full relative animate-slideUp">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="Close popup"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-8">
          <div className="text-center mb-6">
            <div className="bg-gradient-to-r from-amber-500 to-amber-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Gift className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">
              Unlock Exclusive Pricing & Offers
            </h3>
            <p className="text-gray-600">
              Get instant access to special pre-launch deals and early bird discounts
            </p>
          </div>

          {hasSubmitted ? (
            <div className="bg-green-50 border border-green-200 text-green-800 px-6 py-8 rounded-lg text-center">
              <p className="font-semibold text-lg mb-2">Thank you!</p>
              <p className="text-sm">Check your email for exclusive pricing details.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                placeholder="Full Name *"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                required
              />
              <input
                type="tel"
                placeholder="Phone Number *"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                required
              />
              <input
                type="email"
                placeholder="Email Address *"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                required
              />
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold py-4 rounded-lg transition-all transform hover:scale-105 shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Submitting...' : 'Get Exclusive Offers'}
              </button>
              <p className="text-xs text-gray-500 text-center">
                100% privacy guaranteed. No spam.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
