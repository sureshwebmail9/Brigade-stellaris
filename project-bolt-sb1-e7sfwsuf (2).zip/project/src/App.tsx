import { useState } from 'react';
import Navigation from './components/Navigation';
import HeroSection from './components/HeroSection';
import VideoWalkthroughSection from './components/VideoWalkthroughSection';
import OffersSection from './components/OffersSection';
import CredibilitySection from './components/CredibilitySection';
import AmenitiesSection from './components/AmenitiesSection';
import FloorPlansSection from './components/FloorPlansSection';
import PricingSection from './components/PricingSection';
import LocationSection from './components/LocationSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import ConversionPopup from './components/ConversionPopup';

export default function App() {
  const [showPopup, setShowPopup] = useState(false);
  const [popupContext, setPopupContext] = useState('');

  const openPopup = (context: string) => {
    setPopupContext(context);
    setShowPopup(true);
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection onOpenPopup={openPopup} />
      <VideoWalkthroughSection />
      <OffersSection onOpenPopup={openPopup} />
      <CredibilitySection />
      <AmenitiesSection />
      <FloorPlansSection onOpenPopup={openPopup} />
      <PricingSection onOpenPopup={openPopup} />
      <LocationSection />
      <ContactSection />
      <Footer />
      <WhatsAppButton />
      <ConversionPopup
        isOpen={showPopup}
        onClose={() => setShowPopup(false)}
        context={popupContext}
      />
    </div>
  );
}
